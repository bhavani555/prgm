package com.task.taskmaster.viewmodel;

public class ViewDetailsVm {

	private int id;
	private String name;
	private long mobilenumber;
	private String email;
	//private String password;

	private String dateofbirth;
	private String role;

	private String taskname;
	private String estimatedtime;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public long getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(long mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public String getTaskname() {
		return taskname;
	}
	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}
	public String getEstimatedtime() {
		return estimatedtime;
	}
	public void setEstimatedtime(String estimatedtime) {
		this.estimatedtime = estimatedtime;
	}
	
	
	
}
