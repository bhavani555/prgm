package com.task.taskmaster.viewmodel;

import java.util.List;

public class TeamleaderVm {

	public List<Teamleader> teamleader;

	public List<Teamleader> getTeamleader() {
		return teamleader;
	}

	public void setTeamleader(List<Teamleader> teamleader) {
		this.teamleader = teamleader;
	}

	public class Teamleader {
		
		private long id;
		private String name;
		private String role;
		private String taskname;
		private String estimatedtime;
		
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getEstimatedtime() {
			return estimatedtime;
		}

		public void setEstimatedtime(String estimatedtime) {
			this.estimatedtime = estimatedtime;
		}

		public String getRole() {
			return role;
		}

		public void setRole(String role) {
			this.role = role;
		}

		public String getTaskname() {
			return taskname;
		}

		public void setTaskname(String taskname) {
			this.taskname = taskname;
		}

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

	}
}