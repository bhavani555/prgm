package com.task.taskmaster.viewmodel;

public class EditTaskVm {

	private long id;
	private String name;
	private String role;
	private String taskname;
	private String estimatedtime;
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTaskname() {
		return taskname;
	}
	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}
	public String getEstimatedtime() {
		return estimatedtime;
	}
	public void setEstimatedtime(String estimatedtime) {
		this.estimatedtime = estimatedtime;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
}
