package com.task.taskmaster.viewmodel;

public class NewTaskVm {

	private String taskname;
	
	private String estimatedtime;
	private int primaryid;
	private int developerid;
	
	
	public String getTaskname() {
		return taskname;
	}
	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}
	public String getEstimatedtime() {
		return estimatedtime;
	}
	public void setEstimatedtime(String estimatedtime) {
		this.estimatedtime = estimatedtime;
	}
	public int getPrimaryid() {
		return primaryid;
	}
	public void setPrimaryid(int primaryid) {
		this.primaryid = primaryid;
	}
	public int getDeveloperid() {
		return developerid;
	}
	public void setDeveloperid(int developerid) {
		this.developerid = developerid;
	}
	
	
	
	
}
