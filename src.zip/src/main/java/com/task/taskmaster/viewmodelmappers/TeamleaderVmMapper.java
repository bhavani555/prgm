package com.task.taskmaster.viewmodelmappers;

import java.util.*;

import com.task.taskmaster.datamodels.Teamleader;
import com.task.taskmaster.viewmodel.TeamleaderVm;


public class TeamleaderVmMapper {

	public static TeamleaderVm toVm(List<Teamleader> teamleader) {
		
		TeamleaderVm teamleaderVm = new TeamleaderVm();
		
		List<TeamleaderVm.Teamleader> teamleaderVmList = new ArrayList<TeamleaderVm.Teamleader>();
		
		for(Teamleader teamleaders : teamleader) {
			
			TeamleaderVm.Teamleader teamlead = teamleaderVm.new Teamleader();
			
			teamlead.setId(teamleaders.getId());
			teamlead.setName(teamleaders.getName());
			teamlead.setRole(teamleaders.getRole());
			teamlead.setTaskname(teamleaders.getTaskname());
			teamlead.setEstimatedtime(teamleaders.getEstimatedtime());
			
			teamleaderVmList.add(teamlead);
		}
		teamleaderVm.setTeamleader(teamleaderVmList);
		
		return teamleaderVm;
	}
}


