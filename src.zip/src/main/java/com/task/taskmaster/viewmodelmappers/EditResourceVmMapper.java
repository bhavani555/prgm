package com.task.taskmaster.viewmodelmappers;

import com.task.taskmaster.viewmodel.EditResourceVm;

public class EditResourceVmMapper {
	public static EditResourceVm toVm(long id,
			String name,
			String email,
			long mobilenumber,
			String role,
			String dateofbirth) 
	{
		EditResourceVm editResourceVm = new EditResourceVm();
		
		editResourceVm.setId(id);
		editResourceVm.setName(name);
		editResourceVm.setEmail(email);
		editResourceVm.setMobilenumber(mobilenumber);
		editResourceVm.setRole(role);
		editResourceVm.setDateofbirth(dateofbirth);
		
		return editResourceVm;
	}

}
