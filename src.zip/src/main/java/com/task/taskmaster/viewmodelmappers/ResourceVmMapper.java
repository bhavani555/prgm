package com.task.taskmaster.viewmodelmappers;

import java.util.ArrayList;
import java.util.List;

import com.task.taskmaster.datamodels.Resource;
import com.task.taskmaster.viewmodel.ResourceVm;

public class ResourceVmMapper {
	public static ResourceVm toVm(List<Resource> resource) {
		
		ResourceVm resourceVm=new ResourceVm();
		
		List<ResourceVm.Resource> resourceVmList = new ArrayList<ResourceVm.Resource>();
			
		for(Resource resources : resource) {
			
			ResourceVm.Resource resrc = resourceVm.new Resource();
			
			resrc.setId(resources.getId());
			resrc.setName(resources.getName());
			resrc.setTaskname(resources.getTaskname());
			resrc.setStarttime(resources.getStarttime());
			resrc.setEndtime(resources.getEndtime());
			resrc.setStatus(resources.getStatus());
			
			resourceVmList.add(resrc);
		}
		
		resourceVm.setResource(resourceVmList);
		
		return resourceVm;
	}
	
}

