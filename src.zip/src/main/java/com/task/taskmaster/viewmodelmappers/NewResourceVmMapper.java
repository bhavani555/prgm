package com.task.taskmaster.viewmodelmappers;

import com.task.taskmaster.viewmodel.NewResourceVm;

public class NewResourceVmMapper {

	public static NewResourceVm toVm(String name,
			long mobilenumber, 
			String dateofbirth, 
			String email, String password,
			String role ) {
		
		NewResourceVm resourceVm = new NewResourceVm();
		
		resourceVm.setName(name);
		resourceVm.setMobilenumber(mobilenumber);
		resourceVm.setDateofbirth(dateofbirth);
		resourceVm.setEmail(email);
		resourceVm.setPassword(password);
		resourceVm.setRole(role);
		
		return resourceVm;
		
	}
	
	
}
