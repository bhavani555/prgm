package com.task.taskmaster.viewmodelmappers;

import com.task.taskmaster.datamodels.Admin;
import com.task.taskmaster.datamodels.Teamleader;
import com.task.taskmaster.viewmodel.DeleteResourceVm;


public class DeleteResourceVmMapper {
	public static DeleteResourceVm toVm(Admin admin) 
	{
		DeleteResourceVm deleteResourceVm = new DeleteResourceVm();
		
		deleteResourceVm.setId(admin.getId());
		deleteResourceVm.setName(admin.getName());
		deleteResourceVm.setEmail(admin.getEmail());
		deleteResourceVm.setMobilenumber(admin.getMobilenumber());
		deleteResourceVm.setRole(admin.getRole());
		deleteResourceVm.setDateofbirth(admin.getDateofbirth());
		
		return deleteResourceVm;
	}
	public static DeleteResourceVm toVm(Teamleader teamleader) 
	{
		DeleteResourceVm deleteResourceVm = new DeleteResourceVm();
		
	
		deleteResourceVm.setName(teamleader.getName());
		deleteResourceVm.setTaskname(teamleader.getTaskname());
		deleteResourceVm.setRole(teamleader.getRole());
		deleteResourceVm.setEstimatedtime(teamleader.getEstimatedtime());
		
		return deleteResourceVm;
	}
	
}
