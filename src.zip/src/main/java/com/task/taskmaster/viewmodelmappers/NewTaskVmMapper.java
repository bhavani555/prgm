package com.task.taskmaster.viewmodelmappers;

import com.task.taskmaster.viewmodel.NewTaskVm;

public class NewTaskVmMapper {

	public static NewTaskVm toVm(String taskname,
	 String estimatedtime,
	  int primaryid,
	  int developerid) {
									
		NewTaskVm newtaskVm = new NewTaskVm();
		
		newtaskVm.setTaskname(taskname);
		newtaskVm.setEstimatedtime(estimatedtime);
		newtaskVm.setPrimaryid(primaryid);
	
		
		return newtaskVm;
		
		
	}
	
}
