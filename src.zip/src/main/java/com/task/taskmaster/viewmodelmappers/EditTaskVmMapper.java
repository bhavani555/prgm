package com.task.taskmaster.viewmodelmappers;

import com.task.taskmaster.viewmodel.EditTaskVm;

public class EditTaskVmMapper {

	public static EditTaskVm toVm(long id,
									String name,
									String role,
									String taskname, 
									String estimatedtime) {
										
		EditTaskVm editTaskVm = new EditTaskVm();
		
		editTaskVm.setId(id);
		editTaskVm.setName(name);
		editTaskVm.setRole(role);
		editTaskVm.setTaskname(taskname);
		editTaskVm.setEstimatedtime(estimatedtime);
		
		return editTaskVm;
		
		
	}
	
	
}
