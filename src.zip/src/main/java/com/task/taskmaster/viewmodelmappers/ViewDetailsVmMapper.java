package com.task.taskmaster.viewmodelmappers;

import com.task.taskmaster.datamodels.Admin;
import com.task.taskmaster.datamodels.Teamleader;
import com.task.taskmaster.viewmodel.ViewDetailsVm;

public class ViewDetailsVmMapper {

	public static ViewDetailsVm toVm(Admin admin) {
		
		ViewDetailsVm viewDetailsVm = new ViewDetailsVm();
		
		viewDetailsVm.setName(admin.getName());
		viewDetailsVm.setMobilenumber(admin.getMobilenumber());
		viewDetailsVm.setEmail(admin.getEmail());
		//viewDetailsVm.setPassword(admin.getPassword());
		//viewDetailsVm.setPassword(admin.getPassword());
		viewDetailsVm.setDateofbirth(admin.getDateofbirth());
		viewDetailsVm.setRole(admin.getRole());
		
		return viewDetailsVm;
		
	}
	
	public static ViewDetailsVm toVm(Teamleader teamleader) {
		
		ViewDetailsVm viewDetailsVm = new ViewDetailsVm();
		
		viewDetailsVm.setName(teamleader.getName());
		viewDetailsVm.setTaskname(teamleader.getTaskname());
		viewDetailsVm.setEstimatedtime(teamleader.getEstimatedtime());
		viewDetailsVm.setRole(teamleader.getRole());
		
		return viewDetailsVm;
	}

}


