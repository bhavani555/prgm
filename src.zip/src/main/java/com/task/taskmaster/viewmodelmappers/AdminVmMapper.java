package com.task.taskmaster.viewmodelmappers;

import java.util.*;

import com.task.taskmaster.datamodels.Admin;
import com.task.taskmaster.viewmodel.AdminVm;

public class AdminVmMapper {
	public static AdminVm toVm(List<Admin> admin) {
		
		AdminVm adminVm = new AdminVm();

		List<AdminVm.Admin> adminVmList = new ArrayList<AdminVm.Admin>(); 
		
		for(Admin admins : admin) {
			
			AdminVm.Admin admn = adminVm.new Admin();
		
			admn.setId(admins.getId());
			admn.setName(admins.getName());
			admn.setMobilenumber(admins.getMobilenumber());
			admn.setEmail(admins.getEmail());
			//admn.setPassword(admins.getPassword());
			admn.setDateofbirth(admins.getDateofbirth());
			admn.setRole(admins.getRole());

			adminVmList.add(admn);
		}
		
		adminVm.setAdmin(adminVmList);
		
		
		return adminVm;
	}
}

