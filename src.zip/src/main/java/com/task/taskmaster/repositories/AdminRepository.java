package com.task.taskmaster.repositories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.task.taskmaster.datamodel.mappers.AdminMapper;
import com.task.taskmaster.datamodels.Admin;

@Repository
public class AdminRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<Admin> GetDetails() {
		List<Admin> admin = jdbcTemplate.query("CALL GetDetails()",
				new AdminMapper());

		return admin;
	}

	public Admin GetInfoById(long id) {
		
		Admin admin=jdbcTemplate.queryForObject("CALL GetInfoById(?)", 
											new Object[] { id }, 
											new AdminMapper());
		return admin;
	}

	public void Insert(String name, 
			long mobilenumber, 
			String email, 
			String password,
			String dateofbirth, 
			String role) {
		
		jdbcTemplate.update("CALL CreateResource(?,?,?,?,?,?)", 
				name,mobilenumber,email,password,dateofbirth,role);
		
	}
	
	public void delete(int id) {
		jdbcTemplate.update("CALL DeleteResourcesById(?)", id);
		
	}

	public void UpdateResources(long id, String name, String email, String role, String dateofbirth,long mobilenumber) {
		jdbcTemplate.update("CALL UpdateResources(?,?,?,?,?,?)", 
				id,name,mobilenumber,email,dateofbirth,role);
	
	}
}
