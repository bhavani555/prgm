package com.task.taskmaster.repositories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.task.taskmaster.datamodel.mappers.ResourceMapper;
import com.task.taskmaster.datamodel.mappers.StatusMapper;
import com.task.taskmaster.datamodels.Resource;
import com.task.taskmaster.datamodels.Status;



@Repository
public class ResourceRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	public List<Resource>  GetResourceDetailsById(long id)
	{
		List<Resource> resource= jdbcTemplate.query("CALL GetResourceDetailsById(?)", 
														new Object[] {id},
														new ResourceMapper());
		
		return resource;
	}
	/*public void UpdateTimingsById(long id, String name, String taskname) {
		
	jdbcTemplate.update("CALL UpdateTimingsById(?,?,?,?)",
				id,name,taskname);
		
	}*/
	public void UpdateStartTime(long id, String time,String status) {
		
		jdbcTemplate.update("CALL UpdateStartTime(?,?,?)", 
				id,time,status);
		
	}
	public void UpdateEndTime(long id, String time,String status) {
		
		jdbcTemplate.update("CALL UpdateEndTime(?,?,?)", 
				id,time,status);
	}
	public Status  GetTaskstatus(long id)
	{
	Status resource= jdbcTemplate.queryForObject("CALL GetStausById(?)", 
														new Object[] {id},
														new StatusMapper());
		
		return resource;
	}
	
}
