package com.task.taskmaster.repositories;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.task.taskmaster.datamodel.mappers.TeamleaderMapper;
import com.task.taskmaster.datamodels.Teamleader;

@Repository
public class TeamleaderRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<Teamleader> GetResourceDetails(){
		
		List<Teamleader> teamleader = jdbcTemplate.query("CALL GetResourceDetails()",
							new TeamleaderMapper());
		
		return teamleader;
		
	}
	
	public Teamleader GetTaskDetailsById(long id) {
		
		Teamleader teamleader=jdbcTemplate.queryForObject("CALL GetTaskDetailsById(?)", 
											new Object[] { id }, 
											new TeamleaderMapper());
		return teamleader;
	}
	
	public void Insert(String taskname,String estimatedtime,int primaryid,int developerid,HttpSession session) {
		/*long userId = (long)session.getAttribute("id");*/
		long userId=3;
		jdbcTemplate.update("CALL CreateTask(?,?,?,?,?)", 
				taskname,estimatedtime,primaryid,developerid,userId);
		
	}
	
	public void delete(int id) {
		jdbcTemplate.update("CALL DeleteResourcesById(?)", id);
		
	}

	public void UpdateTasksById(long id,String name,String role, String taskname, String estimatedtime) {
		jdbcTemplate.update("CALL UpdateTasksById(?,?,?,?,?)", 
		id,name,role,taskname,estimatedtime);

		}
}


