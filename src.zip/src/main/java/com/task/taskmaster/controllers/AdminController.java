package com.task.taskmaster.controllers;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.task.taskmaster.datamodels.Admin;
import com.task.taskmaster.services.AdminService;
import com.task.taskmaster.viewmodel.AdminVm;
import com.task.taskmaster.viewmodel.DeleteResourceVm;
import com.task.taskmaster.viewmodel.EditResourceVm;
import com.task.taskmaster.viewmodel.NewResourceVm;
import com.task.taskmaster.viewmodel.ViewDetailsVm;
import com.task.taskmaster.viewmodelmappers.AdminVmMapper;
import com.task.taskmaster.viewmodelmappers.DeleteResourceVmMapper;
import com.task.taskmaster.viewmodelmappers.EditResourceVmMapper;
import com.task.taskmaster.viewmodelmappers.NewResourceVmMapper;
import com.task.taskmaster.viewmodelmappers.ViewDetailsVmMapper;

@Controller
public class AdminController {

	Logger logger = LogManager.getLogger(AdminController.class);

	@Autowired
	private AdminService adminService;

	// Get All Details
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public ModelAndView dashboard(HttpSession session, HttpServletRequest request, HttpServletResponse response) {

		ModelAndView mv = new ModelAndView();

		List<Admin> admin = adminService.GetDetails();

		AdminVm adminVm = AdminVmMapper.toVm(admin);

		mv.addObject("adminVm", adminVm);

		mv.setViewName("admin");//

		return mv;

	}

	@RequestMapping(value = "/admin/{id}", method = RequestMethod.GET)
	public ModelAndView details(@PathVariable(value = "id") long id) {

		ModelAndView mv = new ModelAndView();

		Admin admin = adminService.GetInfoById(id);

		ViewDetailsVm viewDetailsVm = ViewDetailsVmMapper.toVm(admin);

		mv.addObject("viewDetailsVm", viewDetailsVm);

		mv.setViewName("ViewDetails");

		return mv;

	}

	// New Resource
	// Create a New Resource - Initial
	@RequestMapping(value = "/admin/new", method = RequestMethod.GET)
	public ModelAndView newResource() {

		ModelAndView mv = new ModelAndView();

		NewResourceVm newresourceVm = NewResourceVmMapper.toVm("", 0, "YYYY-MM-DD", "", "", "");

		mv.addObject("newresourceVm",newresourceVm);

		mv.setViewName("NewResource");

		return mv;

	}

	// Create a New resource
	@RequestMapping(value = "/admin", method = RequestMethod.POST)
	public String resource(NewResourceVm resourceVm) {

		adminService.CreateResource(resourceVm);

		return "redirect:/admin";
	}

	// Delete
	@RequestMapping(value = "/admin/delete/{id}", method = RequestMethod.GET)
	public ModelAndView deleteResource(@PathVariable(value = "id") int id) {

		ModelAndView mv = new ModelAndView();

		Admin admin = adminService.GetInfoById(id);

		DeleteResourceVm deleteResourceVm = DeleteResourceVmMapper.toVm(admin);

		mv.addObject("deleteResourceVm", deleteResourceVm);

		mv.setViewName("deleteresource");

		return mv;

	}

	// Delete A particular resource
	@RequestMapping(value = "/admin/delet/{id}", method = RequestMethod.DELETE)
	public String deleteresource(@PathVariable(value = "id") int id) {

		adminService.deleteresource(id);

		return "redirect:/admin";
	}

	// Update resource
	// Update/Modify a resource - Initial
	@RequestMapping(value = "/admin/edit/{id}", method = RequestMethod.GET)
	public ModelAndView editResource(@PathVariable(value = "id") int id) {

		ModelAndView mv = new ModelAndView();

		Admin admin = adminService.GetInfoById(id);

		EditResourceVm editResourceVm = EditResourceVmMapper.toVm(admin.getId(), 
																admin.getName(), 
				    admin.getEmail(),
				    admin.getMobilenumber(), 
					admin.getRole(),
				admin.getDateofbirth());
				
			

		mv.addObject("editResourceVm", editResourceVm);

		mv.setViewName("edit");

		return mv;
	}

	// Update/Modify a resource
	@RequestMapping(value = "/admin", method = RequestMethod.PUT)
	public String updateResources(EditResourceVm editResourceVm) {

		adminService.UpdateResources(editResourceVm);

		return "redirect:/admin";
	}

}
