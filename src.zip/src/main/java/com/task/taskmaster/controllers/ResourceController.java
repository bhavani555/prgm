package com.task.taskmaster.controllers;

import java.util.List;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;  

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.task.taskmaster.datamodels.Resource;
import com.task.taskmaster.services.ResourceService;
import com.task.taskmaster.viewmodel.ResourceVm;
import com.task.taskmaster.viewmodelmappers.ResourceVmMapper;

@Controller
public class ResourceController {

	@Autowired
	private ResourceService resourceService;
	
	@RequestMapping(value = "/resource", method = RequestMethod.GET)
	public ModelAndView resource(HttpSession session, HttpServletRequest request, HttpServletResponse response ) {

        String userName = (String)session.getAttribute("username");
		
		ModelAndView mv = new ModelAndView();
		
		return mv;
		
	}
	
	@RequestMapping(value = "/resource/{id}", method = RequestMethod.GET)
	public ModelAndView dashboard(@PathVariable(value = "id")long id,HttpSession session) {

		ModelAndView mv = new ModelAndView();

		long userId = (long)session.getAttribute("id");
		
		List<Resource> resource = resourceService.GetResourceDetailsById(id);

		ResourceVm resourceVm = ResourceVmMapper.toVm(resource);

		mv.addObject("resourceVm", resourceVm);

		mv.setViewName("resource");//

		return mv;

	}
	
	@RequestMapping(value = "/starttime/{id}")
	public ModelAndView starttime(@PathVariable(value = "id")long id,HttpSession session) {

        //String userName = (String)session.getAttribute("username");
		
		ModelAndView mv = new ModelAndView();
	
		long userId = (long)session.getAttribute("id");
	
		String status="task started";
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd  HH:mm:ss");
		  LocalDateTime now = LocalDateTime.now();
		String time=dtf.format(now);
		
		resourceService.UpdateStartTime(id,time,status);
		
		String view ="redirect:/resource/"+userId;
		
		mv.setViewName(view);
		
		return mv;
		
	}
	@RequestMapping(value = "/endtime/{id}")
	public ModelAndView endtime(@PathVariable(value = "id")long id,HttpSession session) {

        //String userName = (String)session.getAttribute("username");
		
		ModelAndView mv = new ModelAndView();
		
		long userId = (long)session.getAttribute("id");
		
		String status="task completed";
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd  HH:mm:ss");
		  LocalDateTime now = LocalDateTime.now();
		String time=dtf.format(now);
		
		resourceService.UpdateEndTime(id,time,status);
		
		String view ="redirect:/resource/"+userId;
		
		mv.setViewName(view);
		
		return mv;
		
	}
}	
	
	
	
