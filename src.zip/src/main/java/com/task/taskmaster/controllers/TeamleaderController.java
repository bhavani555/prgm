package com.task.taskmaster.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.task.taskmaster.datamodels.Teamleader;
import com.task.taskmaster.services.TeamleaderService;
import com.task.taskmaster.viewmodel.DeleteResourceVm;
import com.task.taskmaster.viewmodel.EditTaskVm;
import com.task.taskmaster.viewmodel.NewTaskVm;
import com.task.taskmaster.viewmodel.TeamleaderVm;
import com.task.taskmaster.viewmodel.ViewDetailsVm;
import com.task.taskmaster.viewmodelmappers.DeleteResourceVmMapper;
import com.task.taskmaster.viewmodelmappers.EditTaskVmMapper;
import com.task.taskmaster.viewmodelmappers.TeamleaderVmMapper;
import com.task.taskmaster.viewmodelmappers.ViewDetailsVmMapper;


@Controller
public class TeamleaderController {

	@Autowired
	private TeamleaderService teamleaderService;

// Get All Details
	@RequestMapping(value = "/teamleader", method = RequestMethod.GET)
	public ModelAndView dashboard(HttpSession session, HttpServletRequest request, HttpServletResponse response) {

		ModelAndView mv = new ModelAndView();

		List<Teamleader> teamleader = teamleaderService.GetResourceDetails();

		TeamleaderVm teamleaderVm = TeamleaderVmMapper.toVm(teamleader);

		mv.addObject("teamleaderVm", teamleaderVm);

		mv.setViewName("teamleader");//

		return mv;

	}

// New Resource
// Create a New Resource - Initial
	@RequestMapping(value = "/teamleader/new", method = RequestMethod.POST)
	public ModelAndView newResource() {

		ModelAndView mv = new ModelAndView();

		//NewTaskVm newtaskVm = NewTaskVmMapper.toVm("", "", "", "");

		//mv.addObject("newtaskVm", newtaskVm);

		mv.setViewName("create");

		return mv;

	}

// Create a New resource
	@RequestMapping(value = "/teamleader", method = RequestMethod.POST)
	public String resource(NewTaskVm newtaskVm) {

		teamleaderService.CreateTask(newtaskVm);

		return "redirect:/teamleader";
	}


	// Update task
	// Update/Modify a task - Initial
	@RequestMapping(value = "/teamleader/teamleaderedit/{id}", method = RequestMethod.GET)
	public ModelAndView editResource(@PathVariable(value = "id") int id) {

	ModelAndView mv = new ModelAndView();

	Teamleader teamleader = teamleaderService.GetTaskDetailsById(id);

	EditTaskVm editTaskVm = EditTaskVmMapper.toVm(teamleader.getId(),
	teamleader.getName(),
	teamleader.getRole(),
	teamleader.getTaskname(),
	teamleader.getEstimatedtime());

	mv.addObject("editTaskVm", editTaskVm);

	mv.setViewName("teamleaderedit");

	return mv;
	}

	// Update/Modify a resource
	@RequestMapping(value = "/teamleader", method = RequestMethod.PUT)
	public String updateTaskDetails(EditTaskVm editTaskVm) {

	teamleaderService.UpdateTasksById(editTaskVm);

	return "redirect:/teamleader";
	}

}