package com.task.taskmaster.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.task.taskmaster.datamodels.User;
import com.task.taskmaster.services.AuthenticationService;
import com.task.taskmaster.viewmodel.LoginVm;


@Controller
public class AuthenticationController {
	@Autowired
	private AuthenticationService authenticationService;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView login() {

		ModelAndView mv = new ModelAndView();

		LoginVm loginVm = new LoginVm();
		loginVm.setError(null);
		mv.addObject("loginVm", loginVm);

		mv.setViewName("login");

		return mv;
		// return "login";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(LoginVm loginVm, HttpSession session, HttpServletResponse servletResponse) {

		ModelAndView mv = new ModelAndView();
		
		boolean authenticated = authenticationService.Authenticate(loginVm.getUsername(), loginVm.getPassword());
		User user=authenticationService.getRole(loginVm.getUsername(), loginVm.getPassword());
		String role=user.getRole();
		if (authenticated) {

		session.setAttribute("username", loginVm.getUsername());
		session.setAttribute("id", user.getId());
		
		session.setAttribute("authenticated", true);	
		servletResponse.addCookie(new Cookie("COOKIENAME", "Thecookiesgit"));
		mv.addObject("loginVm", loginVm);
		if(role.equals("admin")) {
		mv.setViewName("redirect:/admin");
		}
		if(role.equals("teamleader")) {
		mv.setViewName("redirect:/teamleader");
		}
		if(role.equals("developer")) {
		mv.setViewName("redirect:/resource/"+ user.getId());
		}

		return mv;
		}
		
		loginVm.setError("Wrong Usernameand Password Combination");	
		mv.addObject("loginVm", loginVm);
		
		mv.setViewName("login");
		
		return mv;
		
	}

	/*@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(LoginVm loginVm, HttpSession session, HttpServletResponse servletResponse) {

		ModelAndView mv = new ModelAndView();

		boolean authenticated = authenticationService.Authenticate(loginVm.getUsername(), loginVm.getPassword());
		User user = authenticationService.getRole(loginVm.getUsername(), loginVm.getPassword());
		String role = user.getRole();
		if (authenticated) {

			session.setAttribute("username", loginVm.getUsername());
			session.setAttribute("authenticated", true);
		    session.setAttribute("id", user.getId());
 
			servletResponse.addCookie(new Cookie("COOKIENAME", "Thecookiesgit"));
			mv.addObject("loginVm", user);
			if (role == "admin") {
				mv.setViewName("redirect:/admin");

			}
			if (role == "teamleader") {
				mv.setViewName("teamleader");
			}
			if (role == "developer") {
				mv.setViewName("developer");
			}
			return mv;
			// return "";
		}
		loginVm.setError("Wrong Usernameand Password Combination");	
		mv.addObject("loginVm", loginVm);
		
		mv.setViewName("login");
		return mv;
		
	}*/

	
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session, 
							HttpServletResponse servletResponse) {


		session.invalidate();
		
		
		return "redirect:/";
	}

}
