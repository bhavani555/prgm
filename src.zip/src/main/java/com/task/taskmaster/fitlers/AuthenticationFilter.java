package com.task.taskmaster.fitlers;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

@Configuration
@Order(Ordered.HIGHEST_PRECEDENCE)
public class AuthenticationFilter implements Filter {

	public AuthenticationFilter() {
		super();
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) servletRequest;
		HttpServletResponse res = (HttpServletResponse) servletResponse;
		HttpSession session = req.getSession(false);
		
		String loginURL = req.getContextPath() + "/";

		boolean loggedIn = session != null 
				&& session.getAttribute("username") != null;
		
		String currentUrl = req.getRequestURI();
		if (!currentUrl.contains("/css/") && !currentUrl.contains("/js/") && !currentUrl.contains("/img/")) {

			if (loggedIn == false && !currentUrl.equals("/") && !currentUrl.equals("/login")) {
				res.sendRedirect(loginURL);
			} else {
				filterChain.doFilter(servletRequest, servletResponse);
			}
		}
		else {
			filterChain.doFilter(servletRequest, servletResponse);
		}
	}

	@Override
	public void destroy() {

	}

}
