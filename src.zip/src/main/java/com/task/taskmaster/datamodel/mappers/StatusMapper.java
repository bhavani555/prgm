package com.task.taskmaster.datamodel.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.task.taskmaster.datamodels.Status;



	public class StatusMapper implements RowMapper<Status> {
		@Override
		public Status mapRow(ResultSet rs, int rowNum) throws SQLException {

			Status status = new Status();
		    status.setStatus(rs.getString("status"));
			
			
			
			return status;
		}
	
}
