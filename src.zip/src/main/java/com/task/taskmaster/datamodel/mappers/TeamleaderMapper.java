package com.task.taskmaster.datamodel.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.task.taskmaster.datamodels.Teamleader;


public class TeamleaderMapper implements RowMapper<Teamleader> {
	
	@Override
	public Teamleader mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Teamleader teamleader = new Teamleader();
		
		teamleader.setId(rs.getLong("id"));
		teamleader.setName(rs.getString("name"));
		teamleader.setRole(rs.getString("role"));
		teamleader.setTaskname(rs.getString("taskname"));
		teamleader.setEstimatedtime(rs.getString("estimatedtime"));
		
		
		return teamleader;
		
	}
}
