package com.task.taskmaster.datamodel.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.task.taskmaster.datamodels.Resource;

public class ResourceMapper implements RowMapper<Resource> {

	@Override
	public Resource mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Resource resource = new Resource();
		
		resource.setId(rs.getLong("id"));
		resource.setName(rs.getString("name"));
		resource.setTaskname(rs.getString("taskname"));
		resource.setStarttime(rs.getString("starttime"));
		resource.setEndtime(rs.getString("endtime"));
		resource.setStatus(rs.getString("status"));
		
		return resource;
	}

}
