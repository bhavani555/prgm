package com.task.taskmaster.datamodel.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.task.taskmaster.datamodels.Admin;

public class AdminMapper implements RowMapper<Admin> {
	@Override
	public Admin mapRow(ResultSet rs, int rowNum) throws SQLException {

		Admin admin = new Admin();
	  
		admin.setId(rs.getLong("id"));
		admin.setName(rs.getString("name"));
		admin.setMobilenumber(rs.getLong("mobilenumber"));
		admin.setDateofbirth(rs.getString("dateofbirth"));
		admin.setEmail(rs.getString("email"));
		/*admin.setPassword(rs.getString("password"));*/
		admin.setRole(rs.getString("role"));
		
		
		return admin;
	}
}