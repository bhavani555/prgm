package com.task.taskmaster.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.taskmaster.datamodels.User;
import com.task.taskmaster.repositories.UserRepository;


@Service
public class AuthenticationService {

	@Autowired
	private UserRepository userRepository;

	public boolean Authenticate(String username, String password)
	{
		User user = userRepository.GetByUserNameAndPassword(username, password);
		
		if(user!=null)
		{
			return true;
		}
		
		return false;
	}	
	public User getRole(String username, String password) {
		User  user = userRepository.GetByUserNameAndPassword(username, password);
		
		return user;
		
	}

}
