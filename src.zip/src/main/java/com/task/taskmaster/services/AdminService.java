package com.task.taskmaster.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.taskmaster.datamodels.Admin;
import com.task.taskmaster.repositories.AdminRepository;
import com.task.taskmaster.viewmodel.EditResourceVm;
import com.task.taskmaster.viewmodel.NewResourceVm;

@Service
public class AdminService {
	@Autowired
	private AdminRepository adminRepository;
	
	/* @Autowired 
	 private ResourceRepository resourceRepository;*/
	

	public List<Admin> GetDetails() {

		return adminRepository.GetDetails();
	}

	public Admin GetInfoById(long id) {

		return adminRepository.GetInfoById(id);
	}

	public void CreateResource(NewResourceVm resourceVm) {
		adminRepository.Insert(resourceVm.getName(), resourceVm.getMobilenumber(), resourceVm.getEmail(),
				resourceVm.getPassword(), resourceVm.getDateofbirth(), resourceVm.getRole());
	}

	
	public void UpdateResources(EditResourceVm editResourceVm) {
		
		adminRepository.UpdateResources(editResourceVm.getId(),editResourceVm.getName(),editResourceVm.getEmail(),
				editResourceVm.getRole(),editResourceVm.getDateofbirth(),editResourceVm.getMobilenumber());
		
		
	}
	public void deleteresource(int id) {
		adminRepository.delete(id);

	}

	
}
