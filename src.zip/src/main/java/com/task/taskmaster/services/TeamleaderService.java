package com.task.taskmaster.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.taskmaster.datamodels.Teamleader;
import com.task.taskmaster.repositories.TeamleaderRepository;
import com.task.taskmaster.viewmodel.EditTaskVm;
import com.task.taskmaster.viewmodel.NewResourceVm;
import com.task.taskmaster.viewmodel.NewTaskVm;


@Service
public class TeamleaderService {

@Autowired
private TeamleaderRepository teamleaderRepository;

	public List<Teamleader> GetResourceDetails() {

			return teamleaderRepository.GetResourceDetails();
	}
	public Teamleader GetTaskDetailsById(long id) {

		return teamleaderRepository.GetTaskDetailsById(id);
	}
	public void CreateTask(NewTaskVm newtaskVm) {
		teamleaderRepository.Insert(newtaskVm.getTaskname(), newtaskVm.getEstimatedtime(),
				newtaskVm.getPrimaryid(),newtaskVm.getDeveloperid(),null);
	}

	
	public void UpdateTasksById(EditTaskVm editTaskVm) {
		
		teamleaderRepository.UpdateTasksById(editTaskVm.getId(),editTaskVm.getName(),editTaskVm.getRole(),
				editTaskVm.getTaskname(),
				editTaskVm.getEstimatedtime());
		
		
	}
	public void deleteresource(int id) {
		teamleaderRepository.delete(id);

	}
	
}



