package com.task.taskmaster.services;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.taskmaster.datamodels.Resource;
import com.task.taskmaster.datamodels.Status;
import com.task.taskmaster.repositories.ResourceRepository;
import com.task.taskmaster.viewmodel.ResourceVm;



@Service
public class ResourceService {

	@Autowired
	private ResourceRepository resourceRepository;

	public List<Resource> GetResourceDetailsById(long id) {
		
		return resourceRepository.GetResourceDetailsById(id);
	}

	/*public void UpdateStartTime(long id, String time,String status) {
		
		
		
		resourceRepository.UpdateStartTime(id,time,status);
		
		}

	public void UpdateEndTime(long id, String time,String status) {
		
		
		
		resourceRepository.UpdateEndTime(id,time,status);
		
	}
*/

	/*	public void UpdateTimingsById(ResourceVm resourceVm,HttpSession session) {
		
			long userId = (long)session.getAttribute("id");

			resourceRepository.UpdateTimingsById(
					
				userId,resourceVm.getName(),resourceVm.getTaskname());
	}*/
public void UpdateStartTime(long id, String time,String status) {
		
		Status taskstatus=resourceRepository.GetTaskstatus(id);
		String taskstatuss =taskstatus.getStatus();
		if(taskstatuss.equals("pending")) {
		resourceRepository.UpdateStartTime(id,time,status);
		}
		}

	public void UpdateEndTime(long id, String time,String status) {
		Status taskstatus=resourceRepository.GetTaskstatus(id);
		String taskstatuss =taskstatus.getStatus();
		
		if(taskstatuss.equals("task started")){
		resourceRepository.UpdateEndTime(id,time,status);
		}
	}


}