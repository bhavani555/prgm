USE `taskmaster`;

DELIMITER ^

CREATE PROCEDURE GetUserByEmailAndPassword
(IN email varchar(100), IN password varchar(100))
BEGIN 

SELECT * FROM resources r WHERE r.email = email AND r.password = password;

END ^


CREATE PROCEDURE GetRole
(IN email varchar(100), IN password varchar(100))
BEGIN 
	
	SELECT r.role FROM resources r WHERE r.email = email AND r.password = password;
 
END ^

CREATE PROCEDURE CreateResource

(IN name varchar(255),IN mobilenumber varchar(255),
IN email varchar(255),IN password varchar(255),IN dateofbirth varchar(255),IN role varchar(255))
BEGIN
 
INSERT INTO `resources`(`name`,`mobilenumber`,`email`,`password`,`dateofbirth`,`role`) VALUES
(name, mobilenumber, email,password,dateofbirth,role);

END ^

CREATE PROCEDURE CreateTask

(IN taskname varchar(255),IN estimatedtime varchar(255),
 IN  primaryid int(255), 
 IN developerid int(255),
 IN id int(255))
BEGIN
 
INSERT INTO `task`(`taskname`,`estimatedtime`,`primaryid`,`developerid`,`tlid`) VALUES
 (taskname,estimatedtime,primaryid,developerid,id);

END ^

CREATE PROCEDURE GetResourcesById
(IN id int(255))
BEGIN
 
	SELECT * FROM resources r 
	WHERE r.id = id;

END ^

CREATE PROCEDURE UpdateResources
(IN id int(255),IN name varchar(255),IN mobilenumber varchar(255),
	IN email varchar(255),
	IN dateofbirth varchar(255),IN role varchar(255))
BEGIN

	UPDATE resources r
	SET
	r.id=id,
	r.name = name,
	r.mobilenumber=mobilenumber,
	r.email=email,
	r.dateofbirth=dateofbirth,	
	r.role=role
	WHERE r.id = id;

END ^



CREATE PROCEDURE DeleteResourcesById
(IN resourceid int(255))

BEGIN
	
	DELETE  FROM resources
	
	WHERE id = resourceid;

END ^

CREATE PROCEDURE GetDetails
()

BEGIN

SELECT r.id,r.name,r.mobilenumber,r.email,r.password,r.dateofbirth,r.role FROM resources r WHERE r.role ="teamleader" OR r.role="developer";

END ^


CREATE PROCEDURE GetInfoById
(IN id int(255))
BEGIN
 
	SELECT r.id,r.name, r.mobilenumber, r.email, r.dateofbirth, r.role  FROM resources r
	
	WHERE r.id = id;

END ^

CREATE PROCEDURE UpdateTimingsById
(IN id int(255), IN starttime varchar(255),IN endtime varchar(255),IN remarks varchar(255))

BEGIN

	UPDATE task t
	SET
	t.id = id,
	t.starttime = starttime,
	t.endtime=endtime,
	t.remarks=remarks
	WHERE t.id = id;

END ^

CREATE PROCEDURE DeleteTaskById
(IN taskid int(255))
BEGIN
	
	DELETE FROM task
	
	WHERE id = taskid;

END ^

CREATE PROCEDURE GetResourceDetailsById
(IN id int(11))
BEGIN
 
	SELECT t.id,r.name,t.taskname,t.starttime,t.endtime,t.status FROM resources r INNER JOIN task t
	WHERE r.id=t.developerid AND r.id=id;

END ^

CREATE PROCEDURE GetTimingsById

(IN starttime varchar(255),IN endtime varchar(255),IN remarks varchar(255))
BEGIN
 
INSERT INTO `task`(`starttime`,`endtime`,`remarks`) VALUES
(starttime, endtime, remarks);

END ^

CREATE PROCEDURE GetResourceDetails
()

BEGIN
 
	SELECT t.id,r.name,r.role,t.taskname,t.estimatedtime FROM task t INNER JOIN resources r
	WHERE r.id=t.developerid;
	
	
END ^

CREATE PROCEDURE UpdateTasksById
(IN id int(255), IN name varchar(255),IN role varchar(255),IN taskname varchar(255),IN estimatedtime varchar(255))

BEGIN

UPDATE resources r,task t
SET


r.role=role,
t.taskname=taskname,
t.estimatedtime=estimatedtime

WHERE r.id = t.developerid AND t.id=id;

END ^

CREATE PROCEDURE GetTaskDetailsById
(IN id int(255))

BEGIN
 
	SELECT t.id,r.name,r.role,t.taskname,t.estimatedtime FROM task t INNER JOIN resources r
	WHERE t.developerid=r.id AND t.id=id;
	
	
END ^

 CREATE PROCEDURE UpdateStartTime
(IN idd int(11), IN timee varchar(255), IN status varchar(255))

BEGIN

	UPDATE task t SET  
	t.starttime=timee,
	t.status=status
	
	WHERE t.id= idd;
	
END ^

CREATE PROCEDURE UpdateEndTime
(IN idd int(11), IN timee varchar(255), IN status varchar(255))

BEGIN

	UPDATE task t SET  
	t.endtime=timee,
	t.status=status
	
	WHERE t.id= idd;

	
END ^


CREATE PROCEDURE GetStausById
(IN id int(255))

BEGIN
 
	SELECT t.status FROM task t
	
	WHERE t.id=id;
	
	
END ^



DELIMITER ;

