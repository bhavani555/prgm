CREATE DATABASE `taskmaster`;
USE `taskmaster`;


CREATE TABLE `resources` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`name` varchar(45) DEFAULT NULL,
`mobilenumber` varchar(45) DEFAULT NULL,
`email` varchar(45) DEFAULT NULL,
`password` varchar(45) DEFAULT NULL,
`dateofbirth` date DEFAULT NULL,
`tlid` varchar(45) DEFAULT NULL,
`role` varchar(45) DEFAULT NULL,
PRIMARY KEY (`id`),
UNIQUE KEY `mobilenumber_UNIQUE` (`mobilenumber`),
UNIQUE KEY `email_UNIQUE` (`email`)

) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `task` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`taskname` varchar(45) DEFAULT NULL,
`estimatedtime` varchar(11) DEFAULT NULL,
`starttime` varchar(255) DEFAULT NULL,
`endtime` varchar(255) DEFAULT NULL,
`primaryid` int(11) DEFAULT NULL,
`remarks` varchar(500) DEFAULT NULL,
`developerid` int(11) DEFAULT NULL,
`tlid` int(11) DEFAULT NULL,
`status` varchar(255) DEFAULT NULL,
PRIMARY KEY (`id`),
FOREIGN KEY (`tlid`) REFERENCES `resources` (`id`) ON DELETE CASCADE,
FOREIGN KEY (`developerid`) REFERENCES `resources` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

