#!/bin/bash

mysql -uroot -proot -e "source deletedb.sql"
mysql -uroot -proot -e "source createdb.sql"
mysql -uroot -proot -e "source seed.sql"
mysql -uroot -proot -e "source storedprocs.sql"
