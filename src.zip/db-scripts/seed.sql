use `taskmaster`;


INSERT INTO `resources` (`id`,`name`,`mobilenumber`,`email`,`password`,`dateofbirth`,`tlid`,`role`) VALUES
(1,'rahul','8467876554','rahul@mail.com','password','2005-05-08',null,'teamleader'),
(2,'vamsi','8467876553','vamsi@mail.com','password','2005-06-07',null,'admin'),
(3,'hanish','8467876552','hanish@mail.com','password','2005-07-03 ',null,'teamleader'),
(4,'mahendra','8467876558','mahendra@mail.com','password','2005-02-02 ',1,'developer'),
(5,'prathima','8467876551','prathima@mail.com','password','2005-02-02',1,'developer'),
(6,'divya','946738201','divya@mail.com','password','2005-05-08 ',1,'developer'),
(7,'bhavani','946738202','bhavani@mail.com','password','2005-05-08',3,'developer'),
(8,'neelima','946738204','neelima@mail.com','password','2005-05-08',3,'developer'),
(9,'karthik','946738205','karthik@mail.com','password','2005-05-08',3,'developer'),
(10,'neha','946738255','neha@mail.com','password','2005-05-08',3,'developer');


INSERT INTO `task`(`id`,`taskname`,`estimatedtime`,`starttime`,`endtime`,`primaryid`,`remarks`,`developerid`,`tlid`,`status`) VALUES
(1,'task1',4,null,null,null,null,4,1,'pending'),
(2,'task2',1,null,null,1,null,4,1,'pending'),
(3,'task3',1,null,null,1,null,5,1,'pending'),
(4,'task4',1,null,null,1,null,5,3,'pending'),
(5,'task5',1,null,null,1,'good',6,3,'pending'),
(6,'task6',1,null,null,1,'good',6,3,'pending'),
(7,'task7',1,null,null,1,'good',7,3,'pending'),
(8,'task8',null,null,null,1,'good',7,3,'pending'),
(9,'task9',null,null,null,1,'good',8,3,'pending'),
(10,'task10',null,null,null,1,'good',8,3,'pending'),
(11,'task11',null,null,null,1,'good',10,3,'pending'),
(12,'task12',null,null,null,1,'good',10,3,'pending'),
(13,'task13',null,null,null,1,'good',9,3,'pending'),
(14,'task14',null,null,null,1,'good',9,3,'pending');



